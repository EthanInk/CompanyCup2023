const { log } = require("console");
var fs = require("fs");

// // const files = ['1', '2', '3', '4', '5'];
// files.forEach(fileNumber => {
//   const data = fs.readFileSync(`./${fileNumber}.txt`, { encoding: "utf8", flag: "r" });
//   let lines = data.split("\r\n\r\n");



//   }
// )
const data = `
[
  [3, [(14, 3)]],
  [10, [(40, 77)]],
  [8, [(60, 6)]],
  [10, [(32, 61)]],
  [8, [(40, 8)]],
  [12, [(100, 100)]],
]`;
fs.writeFile('output.txt', data, function(err) {
console.log(err);
});